#ifndef RANDOM_H
#define RANDOM_H

int* gen_direction(void);

#endif
